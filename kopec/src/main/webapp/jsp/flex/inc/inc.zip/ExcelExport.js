
	 function blueOneObjWrite(){
	    document.write('<OBJECT ID="exptool" WIDTH=0 HEIGHT=0 classid="CLSID:50E14959-7BA0-45EE-B2C4-E92AF3C7D7F1"  CODEBASE="./inc/ExcelExport.cab#version=3,0,0,5">');
	    document.write('<PARAM NAME="_Version" VALUE="65536">');
		document.write('<PARAM NAME="_ExtentX" VALUE="2646">');
		document.write('<PARAM NAME="_ExtentY" VALUE="1323">');
		document.write('<PARAM NAME="_StockProps" VALUE="0">');
	    document.write('</OBJECT>');
    }   
	    
	//BlueDataGrid Exel Export
    function exportExcel(){
        if(exptool == null){
            alert('exptool is null');
        }else{
            try{
                exptool.exportExcel();
            }catch(e){
                var errorStr;
                errorStr = e +"\n";
                errorStr +=  e.number +"\n";
                errorStr +=  e.description +"\n";           
                alert(errorStr);
            }
   
        } 
        
    }

	blueOneObjWrite();